plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "se.example.garageopener"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.example.garageopener"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
