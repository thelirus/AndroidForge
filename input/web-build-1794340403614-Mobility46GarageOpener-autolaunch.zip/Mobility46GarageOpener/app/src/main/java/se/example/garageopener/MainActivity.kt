package se.example.garageopener

import android.app.Activity
import android.os.Bundle
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Send exactly one opening request each time the user launches the app.
        if (savedInstanceState == null) {
            executor.execute {
                try {
                    val plate = URLEncoder.encode(VEHICLE_PLATE, "UTF-8")
                    val connection = (URL("$ENDPOINT?plate=$plate").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 15000
                        useCaches = false
                    }
                    try {
                        // Read the response so the request completes; no UI is shown.
                        val stream = if (connection.responseCode in 200..299) {
                            connection.inputStream
                        } else {
                            connection.errorStream
                        }
                        stream?.use { it.readBytes() }
                    } finally {
                        connection.disconnect()
                    }
                } catch (_: Exception) {
                    // Intentionally silent: the app has no buttons or screens.
                } finally {
                    runOnUiThread { finish() }
                }
            }
        } else {
            finish()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val ENDPOINT = "https://qo.mobility46.se/api/v1/public/open/ZIAEWB"
        private const val VEHICLE_PLATE = "OB2284"
    }
}
