# Mobility46 Garage Opener

A minimal Android app that sends one Mobility46 garage-open request whenever the app icon is launched. It has no buttons, form, browser view, or visible screen. After the request completes (or times out/fails), the activity closes.

The vehicle registration number is currently set to `OB2284` in `MainActivity.kt`.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install any requested Android SDK 35 components.
3. Connect the Android phone with USB debugging enabled.
4. Press Run to install it.
5. Tap **Garage opener** on the phone to send the request.

The project has not been built or tested against the live garage service. The app does not call the endpoint during installation or build; it calls it only when launched by the user.
